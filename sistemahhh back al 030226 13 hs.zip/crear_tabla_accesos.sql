-- Tabla de usuarios de acceso al sistema (login).
-- Nivel 3 = máximo (administrador), 2 = estándar, 1 = restringido.
-- El nombre de usuario aquí no tiene que coincidir con el "usuario" interno del sistema.

CREATE TABLE IF NOT EXISTS accesos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(80) NOT NULL UNIQUE,
  clave VARCHAR(255) NOT NULL,
  nivel_acceso TINYINT NOT NULL DEFAULT 2,
  creado_por_id INT NULL,
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_usuario (usuario),
  INDEX idx_nivel (nivel_acceso)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Opcional: insertar primer usuario administrador (nivel 3).
-- Cambiar 'TU_USUARIO' y 'TU_CLAVE' por los que quieras.
-- La clave debe guardarse hasheada con password_hash() en PHP; este INSERT es solo ejemplo.
-- Mejor crear el primer usuario desde la pantalla de "primera vez" o desde gestionar_accesos.php después de ejecutar agregar_primer_acceso.php una vez.

-- Ejemplo (clave 'admin123' hasheada con PASSWORD_DEFAULT):
-- INSERT INTO accesos (usuario, clave, nivel_acceso) VALUES ('admin', '$2y$10$...', 3);
