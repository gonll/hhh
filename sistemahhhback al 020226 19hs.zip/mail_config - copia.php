<?php
/**
 * Configuración para envío de correo por Gmail SMTP.
 * 
 * Para Gmail con verificación en 2 pasos debes usar una "Contraseña de aplicación":
 * 1. Cuenta de Google → Seguridad → Verificación en 2 pasos (activada)
 * 2. Contraseñas de aplicaciones → Generar → elegir "Correo" y "Otro"
 * 3. Pegar aquí la contraseña de 16 caracteres (sin espacios)
 * 
 * Deja estas variables vacías si aún no configuraste; el script te avisará.
 */
$MAIL_SMTP_USER = 'herrerayllobeta@gmail.com';
$MAIL_SMTP_PASS = 'ewiltvmrmzfwuwrs';  // Contraseña de aplicación de Gmail (sin espacios)
$MAIL_FROM_NAME = 'Sistema HHH';
